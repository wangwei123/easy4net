﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Easy4net.Common
{
    public class ColumnInfo : Map
    {        
       
    }
}
